import { Injectable } from '@angular/core';
import { StudentC } from 'src/app/shared/student.modelFi';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class StudentService {

    formDataSt:StudentC;
    readonly rootURL3 ="http://localhost:3001/student";

  constructor(private http : HttpClient) { }

      refreshListSt(){
    //return this.http.get("http://localhost:3001/employees")
    return this.http.get(this.rootURL3)
  }
   deleteEmployee(_id : string){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    // return this.http.delete(this.rootURL2+'/Delete/'+_id);
    return this.http.delete("http://localhost:3001/student"+`/${_id}`);
    // console.log(_id)
  }
  postEmployee2(formData3: StudentC){
    // return this.http.post("http://localhost:3001/employees",{"employee2":formData3})
    return this.http.post("http://localhost:3001/student", formData3)
    .subscribe((data2)=>{console.log(data2)})
    //.subscribe(()=>{})
  }
   putEmployee2(emp7: StudentC){
    return this.http.put("http://localhost:3001/student"+`/${emp7._id}`,emp7)
    // return this.http.put("http://localhost:3001/employees"+`/${emp7._id}`,{"employee2":emp7})
    .subscribe((data3)=>{console.log(data3)})
  }
}
