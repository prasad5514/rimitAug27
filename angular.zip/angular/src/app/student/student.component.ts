import { StudentService } from './../student.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { StudentC } from '../shared/student.modelFi';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  constructor(public serviceSt:StudentService,
    private toastr:ToastrService) { }
        list3:StudentC[];

  ngOnInit() {
        this.resetForm();
    this.refreshList0();
  }

  refreshList0(){
    this.serviceSt.refreshListSt().subscribe((data3)=>{
      this.list3=JSON.parse(JSON.stringify(data3))
    })
    // this.service.refreshList2();
  }
  onEdit(emp: StudentC) {
    // this.service.formData2 = Object.assign({}, emp);
    //  this.service.formData2 = emp;
     this.serviceSt.formDataSt = emp;
  }
  populateForm(emp: StudentC) {
    // this.service.formData2 = Object.assign({}, emp);
     this.serviceSt.formDataSt = Object.assign({}, emp);
    
    // if(form.value._id!=""){
    //   this.service.postEmployee(form.value).subscribe((res)=>{
    //     this.refreshList0();
    //     this.toastr.warning('Updated successfully', 'EMP1. Register');
    //   })
    // } 
    //this.list=JSON.parse(JSON.stringify(this.service.formData2))

    console.log(this.serviceSt.formDataSt)
    // this.toastr.warning(this.serviceSt.formDataSt.phone,this.serviceSt.formDataSt.gender);
    // this.toastr.warning(this.service.formData2.email,this.service.formData2.userName);
    //alert(this.service.formData2.age);
    //this.toastr.warning(this.list.userName);
    //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
    //M.toast({ html: '<ol><li>'+this.list.userName+'</li><li>'+this.list.email+'</li><li>'+this.list.phone+'</li><li>'+this.list.gender+'</li><li>'+this.list.age+'</li></ol>', classes: 'rounded' });
    //alert("<h1>hello</h1>")
    //EmpModV=this.service.formData2;
    // if (confirm(this.service.formData2.email)){
    //   alert("hello")
    // }
  }
    // onDelete(_id: string, form: NgForm) {
    // onDelete(id: number, form:NgForm) {
      onDelete(_id: string) {
        if (confirm('Are you sure to delete this record?')) {
          this.serviceSt.deleteEmployee(_id).subscribe((res) => {
            // this.service.deleteEmployee(id).subscribe(res => {
            //this.service.refreshList();   //wont give proper result
            this.refreshList0();
            //form.reset();
            this.toastr.warning('Deleted successfully', 'EMP1. Register');
            console.log(_id)
            //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
          });
        }
      }
      //
      onSubmit(form:NgForm){
        if(form.value._id==""){
          // this.service.postEmployee(form.value).subscribe((res)=>{
            this.serviceSt.postEmployee2(form.value);
            this.resetForm();
            this.refreshList0();
            //this.toastr.success('inserted successfully','EMP6.Register')
             //console.log(form.value)
         // })
        }
        else{
          // this.service.putEmployee(form.value).subscribe((res)=>{
            this.serviceSt.putEmployee2(form.value);
                 // console.log(form.value)
                 this.resetForm(form);
                 this.refreshList0();
                 //this.toastr.success('Updated successfully','EMP6.Update')
          //})
        }
      }
      resetForm(form?: NgForm) {
        //if(form)
        if (form != null)     //if new data is there
        //if(form)
          form.resetForm();
          //form.reset();
        this.serviceSt.formDataSt = {
          //this.
          _id: '',
          Name: '',
          rollNo: null,
          mobileNo: null
        }
      }

}
