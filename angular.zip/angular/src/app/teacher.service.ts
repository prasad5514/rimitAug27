import { Injectable } from '@angular/core';
import { TeacherC } from 'src/app/shared/teacher.modelFi';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class TeacherService {
  formDataTe:TeacherC;
    readonly rootURL3 ="http://localhost:3001/teacher";

 constructor(private http : HttpClient) { }
    refreshListSt(){
    //return this.http.get("http://localhost:3001/employees")
    return this.http.get(this.rootURL3)
  }
   deleteEmployee(_id : string){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    // return this.http.delete(this.rootURL2+'/Delete/'+_id);
    return this.http.delete("http://localhost:3001/teacher"+`/${_id}`);
    // console.log(_id)
  }
  postEmployee2(formData3: TeacherC){
    // return this.http.post("http://localhost:3001/employees",{"employee2":formData3})
    return this.http.post("http://localhost:3001/teacher", formData3)
    .subscribe((data2)=>{console.log(data2)})
    //.subscribe(()=>{})
  }
   putEmployee2(emp7: TeacherC){
    return this.http.put("http://localhost:3001/teacher"+`/${emp7._id}`,emp7)
    // return this.http.put("http://localhost:3001/employees"+`/${emp7._id}`,{"employee2":emp7})
    .subscribe((data3)=>{console.log(data3)})
  }
}
