import { StudentComponent } from './student/student.component';
import { TeacherComponent } from './teacher/teacher.component';
import { ClassComponent } from './class/class.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


// const routes: Routes = [{path:"",component:EmployeesComponent},
const routes: Routes = [
{path:"student",component:StudentComponent},
{path:"teacher",component:TeacherComponent},
{path:"class",component:ClassComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
