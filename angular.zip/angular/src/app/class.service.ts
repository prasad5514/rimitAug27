import { Injectable } from '@angular/core';
import { ClassC } from 'src/app/shared/class.modelFi';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ClassService {
   formDataCl:ClassC;
    readonly rootURL3 ="http://localhost:3001/class";


  constructor(private http : HttpClient) { }

   refreshListSt(){
    //return this.http.get("http://localhost:3001/employees")
    return this.http.get(this.rootURL3)
  }
   deleteEmployee(_id : string){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    // return this.http.delete(this.rootURL2+'/Delete/'+_id);
    return this.http.delete("http://localhost:3001/class"+`/${_id}`);
    // console.log(_id)
  }
  postEmployee2(formData3: ClassC){
    // return this.http.post("http://localhost:3001/employees",{"employee2":formData3})
    return this.http.post("http://localhost:3001/class", formData3)
    .subscribe((data2)=>{console.log(data2)})
    //.subscribe(()=>{})
  }
   putEmployee2(emp7: ClassC){
    return this.http.put("http://localhost:3001/class"+`/${emp7._id}`,emp7)
    // return this.http.put("http://localhost:3001/employees"+`/${emp7._id}`,{"employee2":emp7})
    .subscribe((data3)=>{console.log(data3)})
  }
}
