export class TeacherC {
    _id: string;
    Name: string;
    employeeId: number;
    subject: string;
}
