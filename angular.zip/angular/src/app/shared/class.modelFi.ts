export class ClassC {
    _id: string;
    standard: number;
    division: string;
    // subject: string;
}
