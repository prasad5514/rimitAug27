export class StudentC {
    _id: string;
    Name: string;
    rollNo: number;
    mobileNo: number;
}
